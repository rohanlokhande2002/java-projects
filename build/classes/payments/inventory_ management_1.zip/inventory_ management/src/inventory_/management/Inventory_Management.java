/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package inventory_.management;


/**
 *
 * @author Lenovo
 */
public class Inventory_Management {

    /**
     *
     * @param args the command line arguments
     */
    
      static LoginPage RetilerLogin = new LoginPage();
  
    public static void main(String[] args) {
        // TODO code application logic here
        RetilerLogin.show();
      
    }
    
}
